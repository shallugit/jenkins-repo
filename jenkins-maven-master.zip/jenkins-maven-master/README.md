# jenkins-maven - project

# sudo usermod -aG docker jenkins
