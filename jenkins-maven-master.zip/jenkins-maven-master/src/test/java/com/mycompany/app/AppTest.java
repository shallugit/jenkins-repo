package com.mycompany.app;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    
    @Test
    public void shouldAnswerWithTrue1()
    {
        assertTrue( true );
    }
    
    @Test
    public void shouldAnswerWithTrue2()
    {
        assertTrue( true );
    }
    
    @Test
    public void shouldAnswerWithTrue3()
    {
        assertTrue( true );
    }
    
    
    @Test
    public void shouldAnswerWithTrue4()
    {
        assertTrue( true );
    }
    
    @Test
    public void shouldAnswerWithTrue5()
    {
        assertTrue( true );
    }
}
